"use client";
import { useState } from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import styles from "./contact.module.css";
import { supabase } from "../../supabase/Supabase";
import StatusPopup from "../messagepopup/Popup";
import { FormikHelpers } from "formik";

interface ContactFormValues {
  name: string;
  email: string;
  phone: string;
  projectType: string;
  message: string;
}

const initialValues: ContactFormValues = {
  name: "",
  email: "",
  phone: "",
  projectType: "",
  message: "",
};

const validationSchema = Yup.object({
  email: Yup.string().email("Invalid email").required("Email is required"),
  name: Yup.string()
    .matches(/^[A-Za-z\s]+$/, "Only alphabets and spaces are allowed")
    .required("Name is required"),
  phone: Yup.string()
    .matches(/^[6-9]\d{9}$/, "Phone number must start with 6, 7, 8 or 9 and be 10 digits")
    .required("Phone number is required"),
  projectType: Yup.string().required("Project type is required"),
  message: Yup.string().required("Message is required"),
});

const Contact = () => {
  const [submitStatus, setSubmitStatus] = useState<
    "idle" | "success" | "error"
  >("idle");
  const [popupOpen, setPopupOpen] = useState(false);

  const handleSubmit = async (
    values: ContactFormValues,
    { resetForm }: FormikHelpers<ContactFormValues>
  ) => {
    try {
      const { error } = await supabase.from("contacts").insert([
        {
          name: values.name,
          email: values.email,
          phone: values.phone,
          project_type: values.projectType,
          message: values.message,
        },
      ]);

      if (error) throw error;

      setSubmitStatus("success");
      setPopupOpen(true);
      resetForm();

      setTimeout(() => {
        setSubmitStatus("idle");
      }, 3000);
    } catch (error) {
      if (error instanceof Error) {
        console.error("Error submitting form:", error.message);
      } else {
        console.error("Error submitting form:", error);
      }
      setSubmitStatus("error");
    }
  };

  return (
    <>
      <section className={styles.contactSection}>
        <div className={styles.container}>


          <div className={styles.sectionHeader}>
            <h2 className={styles.title}>
              Get in <span className={styles.highlight}>Touch</span>
            </h2>
            <p className={styles.subtitle}>Contact us</p>
            <div className={styles.decorativeLine}></div>
          </div>

          <div className={styles.formContainer}>
            <Formik
              initialValues={initialValues}
              validationSchema={validationSchema}
              onSubmit={handleSubmit}
            >
              <Form>
                <div className={styles.formGroup}>
                  <label htmlFor="name" className={styles.label}>
                    Name
                  </label>
                  <Field
                    type="text"
                    id="name"
                    name="name"
                    className={styles.input}
                    placeholder="Enter your name"
                    pattern="[A-Za-z\s]+"
                    onKeyPress={(e: React.KeyboardEvent) => {
                      const char = String.fromCharCode(e.charCode);
                      if (!/[A-Za-z\s]/.test(char)) {
                        e.preventDefault();
                      }
                    }}
                  />
                  <ErrorMessage
                    name="name"
                    component="div"
                    className={styles.errorText}
                  />
                </div>

                <div className={styles.formGroup}>
                  <label htmlFor="phone" className={styles.label}>
                    Mobile Number
                  </label>
                  <Field
                    type="tel"
                    id="phone"
                    name="phone"
                    className={styles.input}
                    placeholder="Enter your mobile number"
                    maxLength={10}
                    pattern="[6-9][0-9]{9}"
                    onKeyPress={(e: React.KeyboardEvent<HTMLInputElement>) => {
                      const char = String.fromCharCode(e.charCode);
                      // Check if it's the first digit
                      if (e.currentTarget.value.length === 0) {
                        // Only allow 6-9 for first digit
                        if (!/[6-9]/.test(char)) {
                          e.preventDefault();
                        }
                      } else {
                        // Allow any digit for remaining positions
                        if (!/[0-9]/.test(char)) {
                          e.preventDefault();
                        }
                      }
                    }}
                  />
                  <ErrorMessage
                    name="phone"
                    component="div"
                    className={styles.errorText}
                  />
                </div>

                <div className={styles.formGroup}>
                  <label htmlFor="email" className={styles.label}>
                    Email
                  </label>
                  <Field
                    type="email"
                    id="email"
                    name="email"
                    className={styles.input}
                    placeholder="Enter your email"
                  />
                  <ErrorMessage
                    name="email"
                    component="div"
                    className={styles.errorText}
                  />
                </div>

                <div className={styles.formGroup}>
                  <label htmlFor="projectType" className={styles.label}>
                    Project Type
                  </label>
                  <Field
                    as="select"
                    id="projectType"
                    name="projectType"
                    className={styles.select}
                  >
                    <option value="">Select a project type</option>
                    <option value="Commercial">Commercial</option>
                    <option value="Residential">Residential</option>
                    <option value="Industrial">Industrial</option>
                  </Field>
                  <ErrorMessage
                    name="projectType"
                    component="div"
                    className={styles.errorText}
                  />
                </div>

                <div className={styles.formGroup}>
                  <label htmlFor="message" className={styles.label}>
                    Message
                  </label>
                  <Field
                    as="textarea"
                    id="message"
                    name="message"
                    className={styles.textarea}
                    placeholder="Enter your message"
                  />
                  <ErrorMessage
                    name="message"
                    component="div"
                    className={styles.errorText}
                  />
                </div>

                <button type="submit" className={styles.submitBtn}>
                  {submitStatus === "success"
                    ? "Message Sent!"
                    : submitStatus === "error"
                      ? "Error Sending"
                      : "Send Message"}
                </button>
              </Form>
            </Formik>
          </div>
          <div className={styles.map}>
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d3422.4539295243862!2d76.79028892607387!3d30.929884376077002!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sVPO%20Haripur%20Sandholi%2C%20Baddi%20Road%2C%20Sandholi%2C%20Solan%2C%20Himachal%20Pradesh-173205!5e0!3m2!1sen!2sin!4v1756292496998!5m2!1sen!2sin"
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>
      <StatusPopup
        type="success"
        message="Your message has been sent successfully!"
        isOpen={popupOpen}
        onClose={() => setPopupOpen(false)}
      />
    </>
  );
};

export default Contact;
